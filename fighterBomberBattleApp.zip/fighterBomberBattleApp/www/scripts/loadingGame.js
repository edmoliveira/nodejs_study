(function () {
    "use strict";

    function LoadingGame(layer) {
        const _layer = layer;
        const _context = _layer.context;
    
        let diameter = 0;
        let circleX = 0;
        let circleY = 0;
    
        let stringTextLoading = "L o a d i n g...";
    
        let animationFrame = null;
        let countText = 0;
        let shadowBlurText = 5;
        let shadowBlurDirection = 0;
    
        let propellerAngle = 0;
        let countPropellerAngle = 0;
        let timePropellerAngle = 0;
        let sleepPropellerAngle = false;
    
        var timerAnimation = 0;
    
        this.refresh = () => {
            diameter = layer.width < layer.height ? layer.width : layer.height;
    
            circleX = layer.width / 2;
            circleY = layer.height / 1.75;
    
            draw();
    
            animationFrame = setInterval(executeAnimationFrame, 10);
        }
    
        this.kill = () => {
            clearInterval(animationFrame);
        }
    
        function executeAnimationFrame() {
            if (timerAnimation >= 200) {
                timerAnimation = 0;
                if (countText == 0) {
                    stringTextLoading = "L o a d i n g   ";
                    countText = 1;
                }
                else if (countText == 1) {
                    stringTextLoading = "L o a d i n g.  ";
                    countText = 2;
                }
                else if (countText == 2) {
                    stringTextLoading = "L o a d i n g.. ";
                    countText = 3;
                }
                else if (countText == 3) {
                    stringTextLoading = "L o a d i n g...";
                    countText = 0;
                }
    
                if (shadowBlurDirection == 0) {
                    shadowBlurText += 5;
    
                    if (shadowBlurText > 20) {
                        shadowBlurDirection = 1;
                    }
                }
                else {
                    shadowBlurText -= 5;
    
                    if (shadowBlurText < 5) {
                        shadowBlurDirection = 0;
                    }
                }
            }
    
            timerAnimation += 10;
    
            if (!sleepPropellerAngle) {
                propellerAngle += 5;
                countPropellerAngle += 1;
    
                if (countPropellerAngle == 45) {
                    countPropellerAngle = 0;
                    sleepPropellerAngle = true;
                }
    
                if (propellerAngle == 360) {
                    propellerAngle = 0;
                }
            }
            else {
                timePropellerAngle += 1;
    
                if (timePropellerAngle > 40) {
                    timePropellerAngle = 0;
                    sleepPropellerAngle = 0;
                }
            }
    
            draw();
        }
    
        function draw() {      
            _context.beginPath();
    
            createLoadingFont();
    
            _context.fillStyle = '#050e40';
            _context.fillRect(0, 0, _layer.width, _layer.height);
    
            const backY1 = _layer.height * 0.8;
            const backY2 = _layer.height * 0.75;
    
            _context.moveTo(0, backY1);
            _context.bezierCurveTo(0, backY2, _layer.width, backY2, _layer.width, backY1);
            _context.lineTo(_layer.width, _layer.height)
            _context.lineTo(0, _layer.height);
            _context.lineTo(0, backY1);        
            
            const gradH = _layer.height - backY1;
    
            const gradientBack = _context.createLinearGradient(0, backY1, 0, backY1 + gradH * 0.9);
    
            gradientBack.addColorStop(0, "#050e40");
            gradientBack.addColorStop(1, "#1127a1");
    
            _context.fillStyle = gradientBack;
            _context.fill();
    
            _context.closePath();
    
            createTextLoading();
            
            createFirstCircle();
    
            createSecondCircle();
    
            _context.save();
            createlittleCircle(0);
            createlittleCircle(90);
            createlittleCircle(180);
            createlittleCircle(270);
            createLinesCircle();
            _context.restore();
            
            createCircleRect()
    
            createCenterCircle(0.35, 0.42, true);
    
            createCenterCircle(0.30, 0.38);
    
            _context.save();
    
            const rotationX = circleX;
            const rotationY = circleY;
    
            _context.translate(rotationX, rotationY);
            _context.rotate(propellerAngle * Math.PI / 180);
            _context.translate(-rotationX, -rotationY);
    
            createPropeller(245.5, 202.5);
            createPropeller(294.5, 337.5);
            createPropeller(22.5, 67.5);
            createPropeller(114.5, 157.5);
    
            _context.restore();
    
            createScrew()
        }
    
        function createLoadingFont() {
            _context.save();
            _context.beginPath();
    
            const fontSize = (_layer.width * 0.08);
    
            _context.font = fontSize + 'px base02';
            _context.fillStyle = "#00F0F0";
            _context.fillText(stringTextLoading, 0, fontSize * 0.85);
    
            _context.closePath();
            _context.restore();
        }
    
        function createTextLoading() {
            _context.save();
            _context.beginPath();
    
            const fontSize = (_layer.width * 0.08);
    
            _context.font = fontSize + 'px viperSquadronSolid';
            
            _context.lineWidth = 2;
    
            _context.shadowColor = '#00ffff';
            _context.shadowBlur = shadowBlurText;
            _context.shadowOffsetX = 0;
            _context.shadowOffsetY = 0;
    
            const x = _layer.width / 2 - _context.measureText(stringTextLoading).width / 2;
    
            _context.fillStyle = "#00F0F0";
            _context.fillText(stringTextLoading, x, fontSize * 0.85);
    
            _context.closePath();
            _context.restore();
        }
    
        function createFirstCircle() {
            _context.save();
            _context.beginPath();
    
            _context.setLineDash([4, 4, 1]);
    
            _context.arc(circleX, circleY, (diameter * 0.8) / 2, 0, 1.5 * Math.PI);
    
            _context.lineWidth = 1;
    
            _context.strokeStyle = '#00ffff';
            _context.stroke();
    
            _context.closePath();
    
            _context.beginPath();
    
            let x = circleX - ((diameter * 0.8) / 2);
    
            _context.moveTo(x, circleY);
            _context.lineTo(x * 0.9, circleY);
            _context.lineTo(x * 0.8, circleY * 1.2);
            _context.lineTo(0, circleY * 1.2);
    
            _context.moveTo(x, circleY);
            _context.lineTo(x * 0.9, circleY);
            _context.lineTo(x * 0.8, circleY - circleY * 0.2);
            _context.lineTo(0, circleY - circleY * 0.2);
    
            x = circleX + ((diameter * 0.8) / 2);
            const lastWidth = _layer.width - x;
    
            _context.moveTo(x, circleY);
            _context.lineTo(x + lastWidth * 0.1, circleY);
            _context.lineTo(x + lastWidth * 0.2, circleY * 1.2);
            _context.lineTo(_layer.width, circleY * 1.2);
    
            _context.moveTo(x, circleY);
            _context.lineTo(x + lastWidth * 0.1, circleY);
            _context.lineTo(x + lastWidth * 0.2, circleY - circleY * 0.2);
            _context.lineTo(_layer.width, circleY - circleY * 0.2);
    
            _context.lineWidth = 1;
    
            _context.strokeStyle = '#00ffff';
            _context.stroke();
    
            _context.closePath();
            _context.restore();
        }
    
        function createSecondCircle() {
            _context.beginPath();
    
            _context.arc(circleX, circleY, (diameter * 0.6) / 2, 1, 2 * Math.PI);
    
            _context.lineWidth = 1;
    
            _context.strokeStyle = '#00ffff';
            _context.stroke();
    
            _context.closePath();
        }
    
        function createlittleCircle(angleInDegrees) {
            const radius = (diameter * 0.7) / 2;
    
            const origX = circleX;
            const origY = circleY;
    
            const x = (radius * Math.cos(angleInDegrees * Math.PI / 180)) + origX;
            const y = (radius * Math.sin(angleInDegrees * Math.PI / 180)) + origY;
    
            _context.beginPath();
    
            _context.shadowColor = '#41fbfb';
            _context.shadowBlur = 20;
            _context.shadowOffsetX = 0;
            _context.shadowOffsetY = 0;
    
            _context.arc(x, y, (diameter * 0.05) / 2, 0, 2 * Math.PI);
    
            _context.fillStyle = '#00ffff';
            _context.fill();
    
            _context.closePath();
    
            _context.beginPath();
    
            _context.arc(x, y, (diameter * 0.045) / 2, 0, 2 * Math.PI);
    
            _context.fillStyle = '#050e40';
            _context.fill();
    
            _context.closePath();
        }
    
        function createLinesCircle() {
            _context.lineWidth = 3;
            _context.strokeStyle = '#00ffff';
    
            _context.beginPath();
            _context.arc(circleX, circleY, (diameter * 0.7) / 2, 1.07 * Math.PI, 1.42 * Math.PI);
            _context.stroke();
            _context.closePath();
    
            _context.beginPath();
            _context.arc(circleX, circleY, (diameter * 0.7) / 2, 1.58 * Math.PI, 1.93 * Math.PI);
            _context.stroke();
            _context.closePath();
    
            _context.beginPath();
            _context.arc(circleX, circleY, (diameter * 0.7) / 2, 0.07 * Math.PI, 0.43 * Math.PI);
            _context.stroke();
            _context.closePath();
    
            _context.beginPath();
            _context.arc(circleX, circleY, (diameter * 0.7) / 2, 0.58 * Math.PI, 0.93 * Math.PI);
            _context.stroke();
            _context.closePath();
        }
    
        function createCircleRect() {
            _context.save();
    
            _context.beginPath();
    
            _context.globalAlpha = 0.2;
    
            _context.arc(circleX, circleY, (diameter * 0.5) / 2, 0, 2 * Math.PI);
    
            _context.lineWidth = (diameter * 0.04);
    
            _context.strokeStyle = '#66FFC2';
            _context.stroke();
    
            _context.closePath();
    
            _context.beginPath();
    
            _context.globalAlpha = 1;
    
            _context.shadowColor = '#41fbfb';
            _context.shadowBlur = 20;
            _context.shadowOffsetX = 0;
            _context.shadowOffsetY = 0;
    
            createLinesCircleRectX_Y(0);
            createLinesCircleRectX_Y(45);
            createLinesCircleRectX_Y(90);
            createLinesCircleRectX_Y(135);
            createLinesCircleRectX_Y(180);
            createLinesCircleRectX_Y(225);
            createLinesCircleRectX_Y(270);
            createLinesCircleRectX_Y(315);
    
            _context.lineWidth = 2;
    
            _context.strokeStyle = '#66FFC2';
            _context.stroke();
    
            _context.closePath();
    
            _context.beginPath();
    
            _context.arc(circleX, circleY, (diameter * 0.46) / 2, 0, 2 * Math.PI);
    
            _context.fillStyle = '#050e40';
            _context.fill();
    
            _context.closePath();
    
            _context.restore();
        }
    
        function createLinesCircleRectX_Y(angleInDegrees) {
            const radius = (diameter * 0.54) / 2;
    
            const origX = circleX;
            const origY = circleY;
    
            const x = (radius * Math.cos(angleInDegrees * Math.PI / 180)) + origX;
            const y = (radius * Math.sin(angleInDegrees * Math.PI / 180)) + origY;
    
            _context.moveTo(origX, origY);
            _context.lineTo(x, y);
        }
    
        function createCenterCircle(percDiameter1, percDiameter2, iSstroke) {
            _context.save();
    
            _context.beginPath();
    
            if (!iSstroke) {
                _context.globalAlpha = 0.5;
            }
    
            _context.shadowColor = '#41fbfb';
            _context.shadowBlur = 20;
            _context.shadowOffsetX = 0;
            _context.shadowOffsetY = 0;
    
            _context.arc(circleX, circleY, (diameter * percDiameter1) / 2, 1 * Math.PI, 0.5 * Math.PI);
    
            const point1 = getPointCenterCircle(180, percDiameter1);
    
            const point2 = getPointCenterCircle(165, percDiameter2);
            const point3 = getPointCenterCircle(105, percDiameter2);
    
            const point4 = getPointCenterCircle(90, percDiameter1);
    
            _context.moveTo(point1.x, point1.y);
            _context.lineTo(point2.x, point2.y);
            _context.lineTo(point3.x, point3.y);
            _context.lineTo(point4.x, point4.y);
    
            if (iSstroke) {
                _context.lineWidth = 1;
    
                _context.strokeStyle = '#66FFC2';
                _context.stroke();
            }
            else {
                _context.fillStyle = '#66FFC2';
                _context.fill();
            }
    
            _context.closePath();
    
            _context.restore();
        }
    
        function createPropeller(angle1, angle2) {
            _context.beginPath();
    
            _context.globalAlpha = 0.1;
    
            const pointLine1 = getPointCenterCircle(angle1, 0.77);
            const pointLine2 = getPointCenterCircle(angle2, 0.77);
    
            const pointCurve1 = getPointCenterCircle(angle1, 0.89);
            const pointCurve2 = getPointCenterCircle(angle2, 0.89);
    
            _context.moveTo(circleX, circleY);
            _context.lineTo(pointLine1.x, pointLine1.y);
    
            _context.bezierCurveTo(pointCurve1.x, pointCurve1.y, pointCurve2.x, pointCurve2.y, pointLine2.x, pointLine2.y)
            _context.lineTo(circleX, circleY);
    
            _context.lineWidth = 1;
    
            _context.fillStyle = '#FFFFFF';
            _context.fill();
    
            _context.closePath();
        }
    
        function createScrew() {
            _context.save();
    
            _context.beginPath();
    
            _context.shadowColor = '#01115F';
            _context.shadowBlur = 20;
            _context.shadowOffsetX = 0;
            _context.shadowOffsetY = 0;
    
            _context.arc(circleX, circleY, (diameter * 0.02) / 2, 0, 2 * Math.PI);
    
            _context.fillStyle = '#01115F';
            _context.fill();
    
            _context.closePath();
    
            _context.beginPath();
    
            _context.arc(circleX, circleY, (diameter * 0.015) / 2, 0, 2 * Math.PI);
    
            _context.fillStyle = '#66FFC2';
            _context.fill();
    
            _context.closePath();
            _context.restore();
        }
    
        function getPointCenterCircle(angleInDegrees, percDiameter) {
            const radius = (diameter * percDiameter) / 2;
    
            const origX = circleX;
            const origY = circleY;
    
            const x = (radius * Math.cos(angleInDegrees * Math.PI / 180)) + origX;
            const y = (radius * Math.sin(angleInDegrees * Math.PI / 180)) + origY;
    
            return { x: x, y: y };
        }
    }

    __protoI__.loadingGameFn = (layer) => { 
		const instance = new LoadingGame(layer);

		Object.freeze(instance);

		return instance;
	};
})();	