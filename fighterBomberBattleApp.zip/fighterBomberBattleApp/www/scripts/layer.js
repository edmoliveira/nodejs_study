(function () {
    "use strict";

    /**
     * These are the layers "Canvas" where all the creation and animation work will be rendered.
     */      
    class Layer {
        //#region Fields

        /**
         * The background canvas html element.
         * @type {HTMLElement}
         */         
        #elBackground;
        /**
         * The scene canvas html element.
         * @type {HTMLElement}
         */         
        #elScene;
        /**
         * The controler canvas html element.
         * @type {HTMLElement}
         */         
        #elControler;

        //#endregion

        //#region Properties

        /**
         * Gets the drawing context on the main layer "Controler".
         * @type {CanvasRenderingContext2D}
         */         
         get context() { return this.#elControler.getContext("2d"); }
         /**
          * Gets the drawing context on the Background layer.
          * @type {CanvasRenderingContext2D}
          */         
         get backgroundContext() { return this.#elBackground.getContext("2d"); }
         /**
          * Gets the drawing context on the Scene layer.
          * @type {CanvasRenderingContext2D}
          */         
         get sceneContext() { return this.#elScene.getContext("2d"); }
         /**
          * Gets the drawing context on the Controler layer.
          * @type {CanvasRenderingContext2D}
          */         
         get controlerContext() { return this.#elControler.getContext("2d");   }                        
         /**
          * Gets the layer width.
          * @type {number}
          */           
         get width() { return this.#elControler.width; }
         /**
          * Gets the layer height.
          * @type {number}
          */           
         get height() { return this.#elControler.height; }
 
         //#endregion        

        //#region Constructor

        /**
         * Initializes a new instance of the Layer class.
         * @param {HTMLElement} elBackgroundCanvas The background canvas html element.
         * @param {HTMLElement} elSceneCanvas The scene canvas html element.
         * @param {HTMLElement} elControlerCanvas The controler canvas html element.
         */         
        constructor(elBackgroundCanvas, elSceneCanvas, elControlerCanvas) {
            this.#elBackground = elBackgroundCanvas;
            this.#elScene = elSceneCanvas;
            this.#elControler = elControlerCanvas;
        }

        //#endregion

        //#region Methods

        //#region public

        /**
         * Sets the layer size.
         * @param {number} width The layer width.
         * @param {number} height The layer height.
         */
        setLayerSize = (width, height) => {
            setCanvasSize(this.#elBackground, width, height);
            setCanvasSize(this.#elScene, width, height);
            setCanvasSize(this.#elControler, width, height);
        };

        /**
         * Clear the main drawing area "Controler"
         */        
        clean = () => {
            this.#elControler.width = this.#elControler.width;
            this.#elControler.height = this.#elControler.height;
        };     
        
        //#endregion

        //#endregion
    }

    //#region Functions

    /**
     * Sets the html element (Canvas) size "width/height | style.width/style.height".
     * @param {HTMLElement} el The html element.
     * @param {number} width The element width.
     * @param {number} height The element height.
     */    
    function setCanvasSize(el, width, height) {
        el.width = width;
        el.height = height;

        el.style.width = width + 'px';
        el.style.height = height + 'px';
    }  

    //#endregion

    __protoI__.layerFn = (elBackgroundCanvas, elSceneCanvas, elControlerCanvas) => { 
		const instance = new Layer(elBackgroundCanvas, elSceneCanvas, elControlerCanvas);

		Object.freeze(instance);

		return instance;
	}; 
})();	