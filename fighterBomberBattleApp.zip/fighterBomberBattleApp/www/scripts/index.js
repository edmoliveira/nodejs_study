(function () {
    "use strict";
    
    // #region Fields

    /**
     * The control class coordinates activities in the game domain.
     * @type {Control}
     */       
    const _oControl = $.createControl();

    //#endregion

    //#region Events

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    //#endregion

    //#region Events functions

    /**
     * This function is called when the document.deviceready event fires.
     * The Cordova was loaded. Run any boot that requires Cordova here. Handles Cordova pause and resume events.
     */      
    function onDeviceReady() {
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );
        document.addEventListener( 'visibilitychange', onVisibilityChange.bind( this ), false );

        //objControl.setDeviceReady();
    };

    /**
     * This function is called when the document.pause event fires.
     * The application has been suspended. Save application state here.
     */      
    function onPause() {
        //objControl.pause();
    };

    /**
     * This function is called when the document.visibilitychange event fires.
     * At the document when the contents of its tab have become visible or have been hidden.
     */      
    function onVisibilityChange() {
        //if (document.visibilityState === 'visible') {
        //    objControl.restart();
        //  } else {
        //    objControl.pause();
        //  }        
    };

    /**
     * This function is called when the document.resume event fires.
     * The application has been reactivated. Restore application state here.
     */      
    function onResume() {
        //objControl.restart();
    };

    //#endregion

    _oControl.setDeviceReady();
} )();
//https://www.c-sharpcorner.com/article/load-html-file-in-windows-10-universal-app/