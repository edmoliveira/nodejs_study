(function () {
    "use strict";

	function Helper() {
        this.getWindowSize = () => {
            const w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName('body')[0];
    
            const width = w.innerWidth || e.clientWidth || g.clientWidth,
            height = w.innerHeight || e.clientHeight || g.clientHeight;
    
            return { width: width, height: height };
        }
    }

    __protoI__.helperFn = () => { 
		const instance = new Helper();

		Object.freeze(instance);

		return instance;
	};
} )();	