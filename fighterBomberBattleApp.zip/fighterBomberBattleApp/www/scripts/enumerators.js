"use strict";

/**
 * Game audio status.
 */      
const AudioStatus = {
    /**
     * Indicates that it can play the audio.
     * @type {number}
     */     
    On: 1,
    /**
     * Indicates that it can't play the audio.
     * @type {number}
     */      
    Off: 0
};
Object.freeze(AudioStatus);