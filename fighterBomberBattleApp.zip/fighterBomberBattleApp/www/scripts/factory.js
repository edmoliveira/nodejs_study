(function () {
    "use strict";

    /**
     * Functions to create instances of classes.
     */      
    class InstanceFunction {
        // #region Fields
        
        /**
         * The function to create an instance of the Control class.
         * @type {function}
         */         
        #_controlFn = null;
        /**
         * The function to create an instance of the Layer class.
         * @type {function}
         */          
        #_layerFn = null;
        /**
         * The function to create an instance of the SoundLibrary class.
         * @type {function}
         */          
        #_soundLibraryFn = null;
        /**
         * The function to create an instance of the ImageLibrary class.
         * @type {function}
         */          
        #_imageLibraryFn = null;
        /**
         * The function to create an instance of the LoadingGame class.
         * @type {function}
         */          
        #_loadingGameFn = null;
        /**
         * The function to create an instance of the Helper class.
         * @type {function}
         */          
        #_helperFn = null;

        // #endregion

        // #region Properties

        /**
         * Gets and sets the function to create an instance of the control class.
         * @type {function}
         */         
        get controlFn() {
            return this.#_controlFn;
        }

        /**
         * Gets and sets the function to create an instance of the Layer class.
         * @type {function}
         */         
        get layerFn() {
            return this.#_layerFn;
        }

        /**
         * Gets and sets the function to create an instance of the SoundLibrary class.
         * @type {function}
         */         
        get soundLibraryFn() {
            return this.#_soundLibraryFn;
        }

        /**
         * Gets and sets the function to create an instance of the ImageLibrary class.
         * @type {function}
         */         
        get imageLibraryFn() {
            return this.#_imageLibraryFn;
        }

        /**
         * Gets and sets the function to create an instance of the LoadingGame class.
         * @type {function}
         */         
        get loadingGameFn() {
            return this.#_loadingGameFn;
        }

        /**
         * Gets and sets the function to create an instance of the Helper class.
         * @type {function}
         */         
        get helperFn() {
            return this.#_helperFn;
        }
       
        set controlFn(fn) {
            this.#_controlFn = fn;
        }
          
        set layerFn(fn) {
            this.#_layerFn = fn;
        }
         
        set soundLibraryFn(fn) {
            this.#_soundLibraryFn = fn;
        }
        
        set imageLibraryFn(fn) {
            this.#_imageLibraryFn = fn;
        }
           
        set loadingGameFn(fn) {
            this.#_loadingGameFn = fn;
        }
         
        set helperFn(fn) {
            this.#_helperFn = fn;
        }

        // #endregion
    }

    /**
     * The background canvas html element.
     * @type {HTMLElement}
     */     
    const _elBackgroundCanvas = document.getElementById('backgroundCanvas'); 
    /**
     * The scene canvas html element.
     * @type {HTMLElement}
     */      
    const _elSceneCanvas = document.getElementById('sceneCanvas'); 
    /**
     * The controler canvas html element.
     * @type {HTMLElement}
     */      
    const _elControlerCanvas = document.getElementById('controlerCanvas'); 

    /**
     * Instance of the InstanceFunction class.
     */     
    const _protoI = new InstanceFunction();
    
    Object.freeze(_protoI);

    window.__protoI__ = _protoI;
    
    window.__protoG__ = {
        createControl: () => _protoI.controlFn(),
        createLayer: () => _protoI.layerFn(_elBackgroundCanvas, _elSceneCanvas, _elControlerCanvas),
        createSoundLibrary: (control) => _protoI.soundLibraryFn(control, 'sounds'),
        createImageLibrary: () => _protoI.imageLibraryFn('styles/fonts', 'images'),
        createLoadingGame: (layer) => _protoI.loadingGameFn(layer),
        createHelper: () => _protoI.helperFn()
    }

    Object.freeze(window.__protoI__);
    Object.freeze(window.__protoG__);
    
    Object.defineProperty(window, "$", { 
        get: function() { return window.__protoG__; },
        configurable: false
    });
} )();