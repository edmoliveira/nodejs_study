(function () {
    "use strict";

	// #region Constants

	/**
	 * Sound status storage key.
	 * @type {string}
	 */ 	
	const KEY_SOUND_STATUS = 'FighterBombBatSoundOn';
	/**
	 * Music status storage key.
	 * @type {string}
	 */ 	
	const KEY_MUSIC_STATUS = 'FighterBombBatMusicOn';

	// #endregion	

    /**
     * The control class coordinates activities in the game domain.
     */   	
	class Control {
		//#region Events functions
				
        /**
         * This function is called when the window.onresize event fires.
         */		
		 #window_Resize() {
			const screen = this.#helper.getWindowSize();

			this.#layer.setLayerSize(screen.width, screen.height);
		}	

        //#endregion

		//#region Fields
		
        /**
         * Helper class to help provide some functionalities.
         * @type {Helper}
         */    		
		#helper;
        /**
         * Layers "Canvas" where all the creation and animation work will be rendered.
         * @type {Layer}
         */    		
		#layer;
        /**
         * Library of all game sounds and music.
         * @type {SoundLibrary}
         */    		
		#soundLibrary;
        /**
         * Library of all game images.
         * @type {ImageLibrary}
         */    		
		#imageLibrary;

		// #endregion

		//#region Properties

        /**
         * Gets the sound status.
         * @type {AudioStatus}
         */    		
		get soundStatus() {
			const soundOnStorage = localStorage.getItem(KEY_SOUND_STATUS);

			return soundOnStorage == null || soundOnStorage === 'true' ? AudioStatus.On : AudioStatus.Off;
		};

        /**
         * Gets the music status.
         * @type {AudioStatus}
         */   		
		get musicStatus() {
			const soundOnStorage = localStorage.getItem(KEY_MUSIC_STATUS);

			return soundOnStorage == null || soundOnStorage === 'true' ? AudioStatus.On : AudioStatus.Off;
		};

		// #endregion		

		//#region Constructor

        /**
         * Initializes a new instance of the Control class.
         */  		
		constructor() {
			this.#helper = $.createHelper();
			this.#layer = $.createLayer();
			this.#soundLibrary = $.createSoundLibrary(this);
			this.#imageLibrary = $.createImageLibrary();

			window.onresize = () => {
				this.#window_Resize();
			};
		}

		//#endregion

        //#region Methods

        //#region public

        /**
         * Indicates that the application is now ready to run.
         */		
		setDeviceReady = () => {
			this.#window_Resize();

			const oLoadingGame = $.createLoadingGame(this.#layer);

			oLoadingGame.refresh();

			let intervalID = setInterval(() => {
				let wasLoaded = true;

				if (this.#imageLibrary.wasLoaded === false) {
					wasLoaded = false;
				}
				else if (this.#soundLibrary.wasLoaded === false) {
					wasLoaded = false;
				}

				if (wasLoaded) {
					clearInterval(intervalID);
					
					oLoadingGame.kill();

					this.#layer.clean();
				}
			}, 50);
		};	
		
        /**
         * Sets the sound status.
         * @param {AudioStatus} status The music status
         */ 		
		setSoundStatus(status) {
			localStorage.setItem(KEY_SOUND_STATUS, status === AudioStatus.On ? 'true' : 'false');
		};
			
        /**
         * Sets the music status.
         * @param {AudioStatus} status The music status
         */ 		
		setMusicStatus(status) {
			localStorage.setItem(KEY_MUSIC_STATUS, status === AudioStatus.On ? 'true' : 'false');
		};		

        //#endregion		

		//#endregion
	}	

	__protoI__.controlFn = () => { 
		const instance = new Control();

		Object.freeze(instance);

		return instance;
	};
} )();

