(function () {
    "use strict";

    /**
     * Image class extension class
     */     
    class ImageLoad {
        // #region Fields

        /**
         * Object that provides the properties and methods used to manipulate image elements
         * @type {Image}
         */          
         #image;        
        /**
         * Indicates whether the document has been uploaded
         * @type {boolean}
         */          
         #wasLoaded = false;

        //#endregion  

        //#region Properties

        /**
         * Gets the Image class instance.
         * @type {Image}
         */    		        
         get instance() { return this.#image; }          
        /**
         * Indicates whether the document has been uploaded.
         * @type {boolean}
         */    		        
         get wasLoaded() { return this.#wasLoaded; }

         //#endregion         

		//#region Constructor

        /**
         * Initializes a new instance of the ImageLoad class.
         * @param {string} filePath The image file path.
         */  	        
        constructor(filePath) {
            this.#image = new Image();

            this.#image.src = filePath;

            this.#image.onerror = () => {
                this.#wasLoaded = true;
            };
        }

        //#endregion
    }      

    /**
     * The game's image library.
     */     
    class ImageLibrary {
        //#region Fields        

        /**
         * The game's image library.
         * @type {object}
         */           
        #libray;
        /**
         * The game's font library.
         * @type {object}
         */          
        #fontsLibray;

        //#endregion

        //#region Properties

        /**
         * Indicates whether all images has been uploaded.
         * @type {boolean}
         */             
        get wasLoaded() {
            let wasLoaded = true;

            for (const prop in this.#fontsLibray) {
                if (this.#fontsLibray[prop].wasLoaded === false) {
                    wasLoaded = false;
                    break;
                }
            }

            if(wasLoaded) {
                for (const prop in this.#libray) {
                    if (this.#libray[prop].wasLoaded === false) {
                        wasLoaded = false;
                        break;
                    }
                }
            }

            return wasLoaded;
        };        

        /**
         * The game's image library.
         * @type {object}
         */           
        get libray() { return this.#libray; } 

        //#endregion

		//#region Constructor

        /**
         * Initializes a new instance of the ImageLibrary class.
         * @param {string} fontsFolder The fonts folder.
         * @param {string} imagesFolder The images folder.
         */        
        constructor(fontsFolder, imagesFolder) {
            const fontPath = fontsFolder + '/';
            const imagePath = imagesFolder + '/';

            this.#fontsLibray = {
                base02Font: new ImageLoad(this.#getPath(fontPath, 'base02.ttf'))
            };

            this.#libray = {
                
            };
        }

        //#endregion

        //#region Methods

        //#region private         

        /**
         * Gets the file path.
         * @param {string} folder The file folder.
         * @param {string} filename The filename.
         * @return {string} The file path.
         */
        #getPath(folder, filename) {
            return folder + filename;
        }      

        //#endregion

        //#endregion
    }	

    __protoI__.imageLibraryFn = (fontsFolder, imagesFolder) => { 
		const instance = new ImageLibrary(fontsFolder, imagesFolder);

		Object.freeze(instance);

		return instance;
	};
})();	