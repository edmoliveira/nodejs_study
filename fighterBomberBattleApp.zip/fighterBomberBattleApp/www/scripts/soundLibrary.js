(function () {
    "use strict";

    /**
     * Audio class extension class for sounds
     */      
    class Sound {
        //#region Fields

        /**
         * The control class coordinates activities in the game domain.
         * @type {Control}
         */       
         #control;
        /**
         * The document to play sounds and music.
         * @type {Audio}
         */           
         #audio;
        /**
         * Indicates whether the document has been uploaded
         * @type {boolean}
         */          
         #wasLoaded = false;

        //#endregion        

        //#region Properties   

        /**
         * Indicates whether the document has been uploaded.
         * @type {boolean}
         */    		        
         get wasLoaded() { return this.#wasLoaded; }

         //#endregion 

		//#region Constructor

        /**
         * Initializes a new instance of the Sound class.
         * @param {Control} control The control class coordinates activities in the game domain.
         * @param {string} filePath The audio file path.
         */  	         
        constructor(control, filePath) {
            this.#control = control;
            this.#audio = new Audio(filePath);

            this.#audio.oncanplay = () => {
                this.#wasLoaded = true;
            };
        }

        //#endregion

        //#region Methods

        //#region public

        /**
         * Starts playing the audio.
         */	        
        play = () => {
            if (this.#control.soundStatus === AudioStatus.On) {
                this.#audio.play();
            }
        };

        /**
         * Pauses playing the audio.
         */	        
        pause = () => {
            if (this.#control.soundStatus === AudioStatus.On) {
                this.#audio.pause();
            }
        };

        /**
         * Clones and starts playing the audio.
         */	        
        clonePlay = () => {
            if (this.#control.soundStatus === AudioStatus.On) {
                const playPromise = this.#audio.cloneNode(false).play();

                if (playPromise !== null) {
                    playPromise.catch(() => { });
                }
            }
        };   
        
        //#endregion

        //#endregion
    }

    /**
     * Audio class extension class for music
     */     
    class Music {
        //#region Fields

        /**
         * The control class coordinates activities in the game domain.
         * @type {Control}
         */       
         #control;
        /**
         * The document to play sounds and music.
         * @type {Audio}
         */           
         #audio;
        /**
         * Indicates whether the document has been uploaded.
         * @type {boolean}
         */          
         #wasLoaded = false;

        //#endregion 

        //#region Properties

        /**
         * Indicates whether the document has been uploaded.
         * @type {boolean}
         */    		        
        get wasLoaded() { return this.#wasLoaded; }

        //#endregion 

		//#region Constructor

        /**
         * Initializes a new instance of the Music class.
         * @param {Control} control The control class coordinates activities in the game domain.
         * @param {string} filePath The audio file path.
         */  	         
         constructor(control, filePath) {
            this.#control = control;
            this.#audio = new Audio(filePath);

            this.#audio.oncanplay = () => {
                this.#wasLoaded = true;
            };
        }

        //#endregion

        //#region Methods

        //#region public

        /**
         * Starts playing the audio.
         */	          
        play = () => {
            if (this.#control.musicStatus === AudioStatus.On) {
                this.#control.play();
            }
        };

        /**
         * Pauses playing the audio.
         */	         
        pause = () => {
            if (this.#control.musicStatus === AudioStatus.On) {
                this.#control.pause();
            }
        };      
        
        //#endregion

        //#endregion
    }

    /**
     * The game's sound and music library.
     */ 
    class SoundLibrary {
        //#region Fields

        /**
         * The files path.
         * @type {string}
         */            
        #path;
        /**
         * The game's sound and music library.
         * @type {object}
         */         
        #libray;

        //#endregion

        //#region Properties

        /**
         * Indicates whether all sounds and music has been uploaded.
         * @type {boolean}
         */          
        get wasLoaded() {
            let wasLoaded = true;

            for (const prop in this.#libray) {
                if (this.#libray[prop].wasLoaded === false) {
                    wasLoaded = false;
                    break;
                }
            }

            return wasLoaded;
        };   

        /**
         * The game's sound and music library.
         * @type {object}
         */           
        get libray() { return this.#libray; }
        
        //#endregion

		//#region Constructor

        /**
         * Initializes a new instance of the SoundLibrary class.
         * @param {Control} control The control class coordinates activities in the game domain.
         * @param {string} folder The sounds and music folder.
         */  	        
        constructor(control, folder) {
            this.#path = folder + '/';

            this.#libray = {
                shot1: new Sound(control, this.#getPath('shot1.mp3')),
                music1: new Music(control, this.#getPath('music1.mp3'))
            };

            Object.freeze(this.#libray);
        }

        //#endregion

        //#region Methods

        //#region private 

        /**
         * Gets the file path.
         * @param {string} filename The filename.
         * @return {string} The file path.
         */    
        #getPath(filename) {
            return this.#path + filename;
        }    

        //#endregion    
        
        //#endregion
    }	

    __protoI__.soundLibraryFn = (control, folder) => { 
		const instance = new SoundLibrary(control, folder);

		Object.freeze(instance);

		return instance;
	};
} )();	